import logo from './logo.svg';
import './App.css';
import {useState} from 'react';
import axios from 'axios';
function App() {
  const [quote, setQuote]=useState('')
  const getquote=()=>{
    axios.get('https://catfact.ninja/fact')
    .then(res=>{
        console.log(res.data.fact)
        setQuote(res.data.fact)
    }).catch(err=>{
        console.log(err)
    })
  }
  return (
    <div className="App">
      
      {quote && <p>{quote}</p>}
      <button onClick={getquote}>Get New Cat Fact</button>
    </div>
  );
}

export default App;
